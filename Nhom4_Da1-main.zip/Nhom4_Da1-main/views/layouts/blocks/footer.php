<!--begin::Footer-->
<footer class="app-footer">
  <!--begin::To the end-->
  <div class="float-end d-none d-sm-inline">Website Quản Lý Tour LUXURY4TRIP</div>
  <!--end::To the end-->
  <!--begin::Copyright-->
  <strong>
    Copyright &copy; <?= date('Y') ?>&nbsp;
    <a href="#" class="text-decoration-none">LUXURY4TRIP</a>.
  </strong>
  All rights reserved.
  <!--end::Copyright-->
</footer>
<!--end::Footer-->

